import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Insurance } from './Insurance.component';

describe('Insurance', () => {
  let component: Insurance;
  let fixture: ComponentFixture<Insurance>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Insurance]
    })
      .compileComponents();

    fixture = TestBed.createComponent(Insurance);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
